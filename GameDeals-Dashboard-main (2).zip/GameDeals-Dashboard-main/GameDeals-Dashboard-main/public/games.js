const KURZ = 24;
let aktualniStore = 'all';

// ── Filtr obchodu ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.filter-chip').forEach(chip => {
        chip.addEventListener('click', function () {
            document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            aktualniStore = this.dataset.store || 'all';

            // Pokud už bylo něco vyhledáno, překreslit
            const query = document.getElementById('game-input').value.trim();
            if (query) hledatHry();
        });
    });
});

// ── Hledání ───────────────────────────────────────────────
async function hledatHry() {
    const query = document.getElementById('game-input').value.trim();
    const vystup = document.getElementById('deals-grid');
    if (!query) return alert("Napiš název hry!");

    vystup.innerHTML = "<p style='color:#a0a0b0; grid-column:1/-1;'>Hledám slevy...</p>";

    const userId = localStorage.getItem('userId') || 1;
    const url = `/search-games?title=${encodeURIComponent(query)}&store=${aktualniStore}&user_id=${userId}`;

    try {
        const response = await fetch(url);
        const hry = await response.json();

        vystup.innerHTML = "";

        if (!hry.length) {
            vystup.innerHTML = "<p style='color:#a0a0b0; grid-column:1/-1;'>Žádné výsledky nenalezeny.</p>";
            return;
        }

        hry.forEach(hra => renderKarta(hra, vystup));

    } catch (err) {
        console.error(err);
        vystup.innerHTML = "<p style='color:#e57373; grid-column:1/-1;'>Chyba při komunikaci se serverem.</p>";
    }
}

// ── Renderování karty ─────────────────────────────────────
function renderKarta(hra, kontejner) {
    const cenaCZK = Math.round(hra.salePrice * KURZ);
    const origCZK = Math.round(hra.normalPrice * KURZ);
    const sleva = Math.round(hra.savings);

    const storeClass = {
        'Steam': 'badge-steam',
        'GOG': 'badge-gog',
        'Epic': 'badge-epic',
        'Humble': 'badge-humble'
    }[hra.storeName] || 'badge-discount';

    const karta = document.createElement('div');
    karta.className = 'card';
    karta.innerHTML = `
        <div style="position:relative; cursor:pointer;" onclick="otevritDetail('${hra.dealID}', '${hra.title.replace(/'/g, "\\'")}')">
            <img src="${hra.thumb}" class="card__image" alt="${hra.title}">
            ${sleva > 0 ? `<span class="badge badge-discount" style="position:absolute; top:8px; right:8px;">-${sleva}%</span>` : ''}
        </div>
        <div class="card__body">
            <div style="margin-bottom:5px;">
                <span class="badge ${storeClass}">${hra.storeName}</span>
            </div>
            <div class="card__title" title="${hra.title}">${hra.title}</div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
                <span>
                    <span class="card__price">${cenaCZK} Kč</span>
                    ${origCZK > cenaCZK ? `<span class="card__price-old">${origCZK} Kč</span>` : ''}
                </span>
                <button class="btn-wl" title="Přidat do watchlistu"
                        onclick="event.stopPropagation(); pridatDoWatchlistu('${hra.title.replace(/'/g, "\\'")}', ${hra.salePrice})">
                    ♡
                </button>
            </div>
        </div>
    `;
    kontejner.appendChild(karta);
}

// ── Watchlist ─────────────────────────────────────────────
async function pridatDoWatchlistu(nazev, cena) {
    const userId = localStorage.getItem('userId');
    if (!userId) return alert("Pro přidání do watchlistu se musíš přihlásit!");

    try {
        const response = await fetch('/watchlist', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, game_title: nazev, target_price: cena })
        });
        const data = await response.json();

        // Animace srdíčka místo alertu
        event.target.textContent = '♥';
        event.target.style.color = '#e57373';
        setTimeout(() => { event.target.textContent = '♡'; event.target.style.color = ''; }, 2000);

    } catch { alert("Chyba při přidávání do watchlistu."); }
}

// ── Detail hry (modal) ────────────────────────────────────
async function otevritDetail(dealID, title) {
    const modal = document.getElementById('modal');
    const modalBody = document.getElementById('modal-body');

    modal.style.display = 'flex';
    modalBody.innerHTML = `<p style="color:#a0a0b0; text-align:center; padding:2rem;">Načítám detail...</p>`;

    try {
        const response = await fetch(`/game-detail/${dealID}`);
        const data = await response.json();

        const game = data.gameInfo;
        const deals = data.cheaperStores || [];
        const cenaCZK = game ? Math.round(parseFloat(game.salePrice) * KURZ) : '—';
        const origCZK = game ? Math.round(parseFloat(game.retailPrice) * KURZ) : '—';

        modalBody.innerHTML = `
            <div style="display:flex; gap:1.25rem; flex-wrap:wrap;">
                ${game?.thumb ? `<img src="${game.thumb}" style="width:200px; border-radius:8px; object-fit:cover; flex-shrink:0;">` : ''}
                <div style="flex:1; min-width:200px;">
                    <h2 style="font-size:1.1rem; margin-bottom:0.5rem;">${title}</h2>
                    ${game?.metacriticScore > 0 ? `<p style="font-size:0.82rem; color:#a0a0b0; margin-bottom:0.75rem;">Metacritic: <strong style="color:#e0e0e0;">${game.metacriticScore}</strong></p>` : ''}
                    <p style="font-size:0.82rem; color:#a0a0b0; margin-bottom:0.25rem;">Aktuální cena</p>
                    <p style="font-size:1.4rem; font-weight:600; color:#00bcd4;">${cenaCZK} Kč
                        <span style="font-size:0.85rem; color:#555; text-decoration:line-through; margin-left:8px;">${origCZK} Kč</span>
                    </p>
                    ${deals.length > 0 ? `
                        <p style="font-size:0.78rem; color:#a0a0b0; margin-top:1rem; margin-bottom:0.4rem; text-transform:uppercase; letter-spacing:0.05em;">Také dostupné v</p>
                        <div style="display:flex; flex-direction:column; gap:4px;">
                            ${deals.map(d => `
                                <div style="display:flex; justify-content:space-between; font-size:0.82rem; padding:4px 0; border-bottom:1px solid #2a2d3a;">
                                    <span style="color:#a0a0b0;">${d.storeName || 'Jiný obchod'}</span>
                                    <span style="color:#00bcd4;">${Math.round(parseFloat(d.salePrice) * KURZ)} Kč</span>
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}
                    <button class="btn btn-primary" style="margin-top:1.25rem; width:100%;"
                        onclick="pridatDoWatchlistu('${title.replace(/'/g, "\\'")}', ${game ? game.salePrice : 0})">
                        ♡ Přidat do watchlistu
                    </button>
                </div>
            </div>
        `;
    } catch {
        modalBody.innerHTML = `<p style="color:#e57373; text-align:center; padding:2rem;">Nepodařilo se načíst detail hry.</p>`;
    }
}

function zavritModal() {
    document.getElementById('modal').style.display = 'none';
}

// Zavřít modal kliknutím mimo
window.addEventListener('click', (e) => {
    const modal = document.getElementById('modal');
    if (e.target === modal) zavritModal();
});