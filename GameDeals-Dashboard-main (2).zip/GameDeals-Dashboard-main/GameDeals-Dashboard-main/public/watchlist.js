document.addEventListener('DOMContentLoaded', async () => {
    const seznam = document.getElementById('watchlist-grid');
    const userId = localStorage.getItem('userId');

    if (!userId) {
        seznam.innerHTML = "<tr><td colspan='6' style='color:#a0a0b0; text-align:center;'>Musíš se nejdříve přihlásit.</td></tr>";
        return;
    }

    try {
        const response = await fetch(`/get-watchlist?user_id=${userId}`);
        const hry = await response.json();

        if (hry.length === 0) {
            seznam.innerHTML = "<tr><td colspan='6' style='color:#a0a0b0; text-align:center;'>Tvůj watchlist je prázdný.</td></tr>";
            return;
        }

        seznam.innerHTML = "";
        hry.forEach(hra => {
            const cenaCZK = Math.round(hra.target_price * 24);
            const datum = new Date(hra.added_date).toLocaleDateString('cs-CZ');
            seznam.innerHTML += `
                <tr>
                    <td>${hra.game_title}</td>
                    <td><span class="badge badge-steam">PC</span></td>
                    <td style="color:#00bcd4;">${cenaCZK} Kč</td>
                    <td style="color:#a0a0b0;">—</td>
                    <td style="color:#a0a0b0;">${datum}</td>
                    <td>
                        <button class="btn btn-outline"
                                style="padding:3px 8px; font-size:0.75rem; color:#e57373; border-color:#e57373;"
                                onclick="smazatZWatchlistu(${hra.id})">
                            Odebrat
                        </button>
                    </td>
                </tr>
            `;
        });
    } catch (err) {
        seznam.innerHTML = "<tr><td colspan='6' style='color:#e57373;'>Chyba při komunikaci se serverem.</td></tr>";
    }
});

async function smazatZWatchlistu(id) {
    if (!confirm("Opravdu chceš tuto hru smazat?")) return;
    try {
        const response = await fetch('/delete-watchlist/' + id, { method: 'DELETE' });
        const data = await response.json();
        if (response.ok) {
            location.reload();
        } else {
            alert("Chyba: " + data.error);
        }
    } catch (err) {
        alert("Chyba při mazání.");
    }
}